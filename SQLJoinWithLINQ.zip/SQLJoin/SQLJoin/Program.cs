﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SQLJoin
{
    class Program
    {
        static void Main(string[] args)
        {
            //Inner join
            Console.WriteLine("Inner Join Example");
            Console.WriteLine("=====================================================================");
            using (JoinEntities Context = new JoinEntities())
            {
                var innerJoin = from e in Context.EmployeeMasters
                                join d in Context.DepartmentMasters on e.DepartmentId equals d.DepartmentId
                                select new
                                {
                                    EmployeeCode = e.Code,
                                    EmployeeName = e.Name,
                                    DepartmentName = d.Name
                                };
                Console.WriteLine("Employee Code\tEmployee Name\tDepartment Name");
                foreach (var data in innerJoin)
                {
                    Console.WriteLine(data.EmployeeCode + "\t\t" + data.EmployeeName + "\t" + data.DepartmentName);
                }
            }

            Console.WriteLine("Left Outer Join Example");
            Console.WriteLine("=====================================================================");
            //Left Outer join
            using (JoinEntities Context = new JoinEntities())
            {
                var leftOuterJoin = from e in Context.EmployeeMasters
                                    join d in Context.DepartmentMasters on e.DepartmentId equals d.DepartmentId into dept
                                    from department in dept.DefaultIfEmpty()
                                    select new
                                    {
                                        EmployeeCode = e.Code,
                                        EmployeeName = e.Name,
                                        DepartmentName = department.Name
                                    };
                Console.WriteLine("Employee Code\tEmployee Name\tDepartment Name");
                foreach (var data in leftOuterJoin)
                {
                    Console.WriteLine(data.EmployeeCode + "\t\t" + data.EmployeeName + "\t" + data.DepartmentName);
                }
            }

            //Right Outer join
            Console.WriteLine("Right Outer Join Example");
            Console.WriteLine("=====================================================================");
            using (JoinEntities Context = new JoinEntities())
            {
                var rightOuterJoin = from d in Context.DepartmentMasters
                                     join e in Context.EmployeeMasters on d.DepartmentId equals e.DepartmentId into emp
                                     from employee in emp.DefaultIfEmpty()
                                     select new
                                     {
                                         EmployeeCode = employee.Code,
                                         EmployeeName = employee.Name,
                                         DepartmentName = d.Name
                                     };
                Console.WriteLine("Employee Code\tEmployee Name\tDepartment Name");
                foreach (var data in rightOuterJoin)
                {
                    Console.WriteLine(data.EmployeeCode + "\t\t" + data.EmployeeName + "\t" + data.DepartmentName);
                }
            }

            //Full outer join
            Console.WriteLine("Full outer Example");
            Console.WriteLine("=====================================================================");
            using (JoinEntities Context = new JoinEntities())
            {
                var leftOuterJoin = from e in Context.EmployeeMasters
                                    join d in Context.DepartmentMasters on e.DepartmentId equals d.DepartmentId into dept
                                    from department in dept.DefaultIfEmpty()
                                    select new
                                    {
                                        EmployeeCode = e.Code,
                                        EmployeeName = e.Name,
                                        DepartmentName = department.Name
                                    };
                var rightOuterJoin = from d in Context.DepartmentMasters
                                     join e in Context.EmployeeMasters on d.DepartmentId equals e.DepartmentId into emp
                                     from employee in emp.DefaultIfEmpty()
                                     select new
                                     {
                                         EmployeeCode = employee.Code,
                                         EmployeeName = employee.Name,
                                         DepartmentName = d.Name
                                     };
                leftOuterJoin = leftOuterJoin.Union(rightOuterJoin);
                Console.WriteLine("Employee Code\tEmployee Name\tDepartment Name");
                foreach (var data in leftOuterJoin)
                {
                    if (!string.IsNullOrEmpty(data.EmployeeCode))
                        Console.WriteLine(data.EmployeeCode + "\t\t" + data.EmployeeName + "\t" + data.DepartmentName);
                    else
                        Console.WriteLine(data.EmployeeCode + "\t\t" + data.EmployeeName + "\t\t" + data.DepartmentName);
                }
            }


            //Cross join
            Console.WriteLine("Cross Join Example");
            Console.WriteLine("=====================================================================");
            using (JoinEntities Context = new JoinEntities())
            {
                var crossJoin = from e in Context.EmployeeMasters
                                from d in Context.DepartmentMasters
                                select new
                                {
                                    EmployeeCode = e.Code,
                                    EmployeeName = e.Name,
                                    DepartmentName = d.Name
                                };
                Console.WriteLine("Employee Code\tEmployee Name\tDepartment Name");
                foreach (var data in crossJoin)
                {
                    Console.WriteLine(data.EmployeeCode + "\t\t" + data.EmployeeName + "\t" + data.DepartmentName);
                }
            }
            // Group Join using INTO keyword
            Console.WriteLine("Group Join Example (using INTO keyword)");
            Console.WriteLine("=====================================================================");
            using (JoinEntities Context = new JoinEntities())
            {
                var groupJoin = from d in Context.DepartmentMasters
                                join e in Context.EmployeeMasters on d.DepartmentId equals e.DepartmentId into emp
                                select new
                                {
                                    DeparmentCode = d.Code,
                                    DeparmentName = d.Name,
                                    Employee = emp
                                };

                foreach (var data in groupJoin)
                {
                    Console.WriteLine("Department:" + data.DeparmentCode + " - " + data.DeparmentName);
                    if (data.Employee != null && data.Employee.Count() > 0)
                    {
                        Console.WriteLine("Employee Code\tEmployee Name");
                        foreach (var empData in data.Employee)
                        {
                            Console.WriteLine(empData.Code + "\t\t" + empData.Name);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Department has no employee.");
                    }
                    Console.WriteLine("");
                    Console.WriteLine("");
                }
            }

            //Group Join Example (using sub query)
            Console.WriteLine("Group Join Example (using sub query)");
            Console.WriteLine("=====================================================================");
            using (JoinEntities Context = new JoinEntities())
            {
                var groupJoin = from d in Context.DepartmentMasters
                                select new
                                {
                                    DeparmentCode = d.Code,
                                    DeparmentName = d.Name,
                                    Employee = (from e in Context.EmployeeMasters
                                                where e.DepartmentId == d.DepartmentId
                                                select e)
                                };

                foreach (var data in groupJoin)
                {
                    Console.WriteLine("Department:" + data.DeparmentCode + " - " + data.DeparmentName);
                    var employees = data.Employee as IEnumerable<EmployeeMaster>;
                    if (employees != null && employees.Count() > 0)
                    {
                        Console.WriteLine("Employee Code\tEmployee Name");
                        foreach (var empData in employees)
                        {
                            Console.WriteLine(empData.Code + "\t\t" + empData.Name);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Department has no employee.");
                    }
                    Console.WriteLine("");
                    Console.WriteLine("");
                }
            }
        }
    }
}
