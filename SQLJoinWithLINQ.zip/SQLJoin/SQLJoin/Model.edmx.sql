
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 05/28/2014 17:23:55
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Testdb];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_EmployeeMaster_DepartmentMaster]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[EmployeeMaster] DROP CONSTRAINT [FK_EmployeeMaster_DepartmentMaster];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[DepartmentMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[DepartmentMaster];
GO
IF OBJECT_ID(N'[dbo].[EmployeeMaster]', 'U') IS NOT NULL
    DROP TABLE [dbo].[EmployeeMaster];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'DepartmentMasters'
CREATE TABLE [dbo].[DepartmentMasters] (
    [DepartmentId] int IDENTITY(1,1) NOT NULL,
    [Code] varchar(10)  NULL,
    [Name] varchar(50)  NULL
);
GO

-- Creating table 'EmployeeMasters'
CREATE TABLE [dbo].[EmployeeMasters] (
    [EmployeeId] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(50)  NULL,
    [Code] varchar(10)  NULL,
    [DepartmentId] int  NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [DepartmentId] in table 'DepartmentMasters'
ALTER TABLE [dbo].[DepartmentMasters]
ADD CONSTRAINT [PK_DepartmentMasters]
    PRIMARY KEY CLUSTERED ([DepartmentId] ASC);
GO

-- Creating primary key on [EmployeeId] in table 'EmployeeMasters'
ALTER TABLE [dbo].[EmployeeMasters]
ADD CONSTRAINT [PK_EmployeeMasters]
    PRIMARY KEY CLUSTERED ([EmployeeId] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [DepartmentId] in table 'EmployeeMasters'
ALTER TABLE [dbo].[EmployeeMasters]
ADD CONSTRAINT [FK_EmployeeMaster_DepartmentMaster]
    FOREIGN KEY ([DepartmentId])
    REFERENCES [dbo].[DepartmentMasters]
        ([DepartmentId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_EmployeeMaster_DepartmentMaster'
CREATE INDEX [IX_FK_EmployeeMaster_DepartmentMaster]
ON [dbo].[EmployeeMasters]
    ([DepartmentId]);
GO

---------------------------------------
--Script to insert dummy data
---------------------------------------
SET IDENTITY_INSERT [dbo].[DepartmentMaster] ON
INSERT [dbo].[DepartmentMaster] ([DepartmentId], [Code], [Name]) VALUES (1, N'Admin', N'Admin')
INSERT [dbo].[DepartmentMaster] ([DepartmentId], [Code], [Name]) VALUES (2, N'HR', N'HR')
INSERT [dbo].[DepartmentMaster] ([DepartmentId], [Code], [Name]) VALUES (3, N'Devlopment', N'Devlopment')
SET IDENTITY_INSERT [dbo].[DepartmentMaster] OFF

SET IDENTITY_INSERT [dbo].[EmployeeMaster] ON
INSERT [dbo].[EmployeeMaster] ([EmployeeId], [Name], [Code], [DepartmentId]) VALUES (1, N'Tejas Trivedi', N'TT', 1)
INSERT [dbo].[EmployeeMaster] ([EmployeeId], [Name], [Code], [DepartmentId]) VALUES (2, N'Jignesh Trivedi', N'JT', 2)
INSERT [dbo].[EmployeeMaster] ([EmployeeId], [Name], [Code], [DepartmentId]) VALUES (3, N'Rakesh Trivedi', N'RT', NULL)
SET IDENTITY_INSERT [dbo].[EmployeeMaster] OFF


-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------

