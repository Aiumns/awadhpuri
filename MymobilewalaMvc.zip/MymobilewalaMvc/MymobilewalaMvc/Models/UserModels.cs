﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace MymobilewalaMvc.Models
{
    public class UserModels
    {
        public int User_Id { get; set; }

        [Required(ErrorMessage = "User Name is required.")]
        [Display(Name = "User Name")]
        public string User_Name { get; set; }

        [Required(ErrorMessage = "User Address is required.")]
        [Display(Name = "User Address")]
        public string User_Address { get; set; }

        [Required(ErrorMessage = "Email Id is required.")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email Id")]
        public string User_Email { get; set; }

        [Required(ErrorMessage = "Mobile No is required.")]
        [StringLength(10, ErrorMessage = "Mobile No Must Be 10th Digit", MinimumLength = 10)]
        [DataType(DataType.PhoneNumber)]
        [Display(Name = "Mobile No")]
        public string User_MobileNo { get; set; }


        [Display(Name = "User Photo")]
        [DataType(DataType.ImageUrl)]
        public string User_User_Pic { get; set; }

        [Required(ErrorMessage = "Pin Code is required.")]
        [StringLength(10, ErrorMessage = "Pin Code Must Be 6th Digit", MinimumLength = 10)]
        [Display(Name = "Pin Code")]
        public int User_pincode { get; set; }


        [Required(ErrorMessage = "Password is required.")]
        [StringLength(10, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "User Password")]
        public string User_password { get; set; }

        [Required(ErrorMessage = "Confirmation Password is required.")]
        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("User_password", ErrorMessage = "Password and Confirmation Password must match.")]
        public string ConfirmUser_password { get; set; }     
                
    }
}