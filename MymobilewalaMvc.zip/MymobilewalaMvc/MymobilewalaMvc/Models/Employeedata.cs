﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Web.Mvc;
namespace MymobilewalaMvc.Models
{
    public class Employeedata
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter Employee Name")]
        [Display(Name = "Enter Employee Name")]
        [StringLength(15, MinimumLength = 3, ErrorMessage = "Employee Name must be between 3 and 15 characters!")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Enter Employee Address")]
        [Display(Name = "Enter Employee Address")]       
        public string Address { get; set; }

        [Required(ErrorMessage="Select Gender")]
        [Display(Name="Select Gender")]
        public string Gender { get; set; }

        //[Required(ErrorMessage = "Select Country")]
        //[Display(Name = "Select Country")]
        //public string Country { get; set; }

        //[Required(ErrorMessage = "Select State")]
        //[Display(Name = "Select State")]
        //public string State { get; set; }

        //[Required(ErrorMessage = "Select City")]
        //[Display(Name = "Select City")]
        //public string City { get; set; }

        public DataSet StoreAllEmployee { get; set; }

        //public List<Employeedata> EmployeeInfo { get; set; }

        //public Employeedata()
        //{
        //    this.Countries = new List<SelectListItem>();
        //    this.States = new List<SelectListItem>();
        //    this.Cities = new List<SelectListItem>();
        //}

        //public List<SelectListItem> Countries { get; set; }
        //public List<SelectListItem> States { get; set; }
        //public List<SelectListItem> Cities { get; set; }

        //public int CountryId { get; set; }
        //public int StateId { get; set; }
        //public int CityId { get; set; }
    }
}