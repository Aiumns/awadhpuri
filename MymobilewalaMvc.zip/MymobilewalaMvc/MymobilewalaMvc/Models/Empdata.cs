﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
//using System.Web.WebPages.Html;
namespace MymobilewalaMvc.Models
{
    public partial class Country
    {
        public int CountryID { get; set; }
        public string CountryName { get; set; }     
    }
    public partial class State
    {
        public int StateID { get; set; }
        public string StateName { get; set; }
        public int CountryID { get; set; }
    }
    public partial class City
    {
        public int id { get; set; }
        public string Name { get; set; }
        public int StateID { get; set; }
        public int Countryid { get; set; }
    }  
  
    public class Empdata
    {
        public Empdata()
        {
            this.tblcountry = new List<SelectListItem>();
            this.tblState = new List<SelectListItem>();
            this.tblcity = new List<SelectListItem>();
        }

        public List<SelectListItem> tblcountry { get; set; }
        public List<SelectListItem> tblState { get; set; }
        public List<SelectListItem> tblcity { get; set; }

        public int CountryId { get; set; }
        public int StateId { get; set; }
        public int CityId { get; set; }
        public string CountryName { get; set; }
        public string StateName { get; set; }
        public string CityName { get; set; }

        //[Required, Display(Name = "Country")]
        //public int Country { get; set; }

        //[Required, Display(Name = "State")]
        //public int State { get; set; }

        //[Required, Display(Name = "City")]
        //public int City { get; set; }

        public int ID { get; set; }      
        [Required(ErrorMessage = "Please Enter Name")]
        [Display(Name = "Enter Name")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Name must be between 3 and 50 characters!")]
        public string Name { get; set; }      
        [Required(ErrorMessage = "Please Enter Address")]
        [Display(Name = "Enter Address")]
        [MaxLength(100, ErrorMessage = "Exceeding Limit")] 
        public string Address { get; set; }     
      
        public DataSet StoreAllEmpData { get; set; }       

        //public Gender EmployeeGender { get; set; }
        //public enum Gender { Male, Female}
        //[Required(ErrorMessage = "Please Enter Country")]
        //[Display(Name = "Enter Country")]
        //[DataType(DataType.Integer)]
        //public int CountryId { get; set; }
        //[Required(ErrorMessage = "Please Enter State")]
        //[Display(Name = "Enter State")]
        //[DataType(DataType.Text)]
        //public int StateId { get; set; }
        //[Required(ErrorMessage = "Please Enter City")]
        //[Display(Name = "Enter City")]
        //[DataType(DataType.Text)]
        //public int CityId { get; set; }
        //[Required(ErrorMessage = "Please Enter Country")]

        //[Display(Name = "Enter Country")]
        //[DataType(DataType.Text)]
        //public string Country { get; set; }
        //[Required(ErrorMessage = "Please Enter Country")]
        //[Display(Name = "Enter Country")]
        //[DataType(DataType.Text)]
        //public List<Empdata> CountryList { get; set; }
        //[Required(ErrorMessage = "Please Enter State")]
        //[Display(Name = "Enter State")]
        //[DataType(DataType.Text)]
        //public string State { get; set; }
        //[Required(ErrorMessage = "Please Enter City")]
        //[Display(Name = "Enter City")]
        //[DataType(DataType.Text)]
        //public string City { get; set; }        
    }    
}