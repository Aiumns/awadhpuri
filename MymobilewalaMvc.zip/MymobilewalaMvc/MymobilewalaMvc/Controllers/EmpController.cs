﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MymobilewalaMvc.Models;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
namespace MymobilewalaMvc.Controllers
{
    public class EmpController : Controller
    {
        public ActionResult InsertEmp() // Calling when we first hit controller
         {
               Empdata model = new Empdata();               
               ViewBag.tblcountry = PopulateDropDown("SELECT CountryId, CountryName FROM tblcountry", "CountryName", "CountryId");
               if (TempData["success"] !=null)  //checking model is valid or not               
                {
                    //ViewData["result3"] = TempData.Peek("result2").ToString();
                    ViewData["insertStatus"] = Convert.ToString(TempData["success"]);                     
                }
                else
                {
                    ViewData["insertStatus"] = null; //TempData.Peek("result2").ToString();
                }
                //ViewData["result3"] = TempData.Peek("result2").ToString();
                // string data = TempData.Peek("result2").ToString();
                return View(model); 

                #region commented

            //Empdata objEmp = new Empdata();  
            //DataSet ds = new DataSet();
            //string constr = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;          
            //using (SqlConnection con = new SqlConnection(constr))
            //{
            //    using (SqlCommand cmd = new SqlCommand("select Countryid,CountryName FROM tblcountry", con))
            //    {
            //        con.Open();
            //        SqlDataAdapter da = new SqlDataAdapter(cmd);
            //        da.Fill(ds);
            //        List<Empdata> CountryList = new List<Empdata>();
            //        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            //        {
            //            Empdata uobj = new Empdata();
            //            uobj.Country = ds.Tables[0].Rows[i]["CountryName"].ToString();
            //            CountryList.Add(uobj);
            //        }
            //        //objuser.CountryList = CountryList;
            //        ViewBag.CountryItemList = CountryList;
            //    }
            //    con.Close();
            //}
            //return View(objEmp);

            #endregion
         }
      
        [HttpPost]
        //[ActionName("InsertEmp")]
        public ActionResult InsertEmp(Empdata MB)  // Calling on http post (on Submit)
        {
            if (ModelState.IsValid)  //checking model is valid or not
            {
                DataAccessLayer.DBdata objDB = new DataAccessLayer.DBdata(); //calling class DBdata
                string result = objDB.InsertEmp(MB);     // passing Value to DBClass from model
               // TempData.Add("result2", result.ToString());
                TempData["success"] = result; //"Successfully updated";
                //ViewData["result2"] = result; // for dislaying message after saving storing output.
                //ModelState.Clear(); //clearing model
                //return View(); 
                return RedirectToAction("InsertEmp");
                //return RedirectToAction("InsertEmp", "Emp", new { area = "" }); 
            }
            else
            {
                ModelState.AddModelError("", "Error in saving data");
                return View();
            }
        }      

        [HttpPost]
        [ActionName("FillDropDown")]
        public ActionResult InsertEmp(int countryId, int stateId, int cityId)
        {
            Empdata model = new Empdata();
            model.tblcountry = PopulateDropDown("SELECT CountryId, CountryName FROM tblcountry", "CountryName", "CountryId");
            model.tblState = PopulateDropDown("SELECT StateId, StateName FROM tblState WHERE CountryId = " + countryId, "StateName", "StateId");
            model.tblcity = PopulateDropDown("SELECT CityId, CityName FROM tblcity WHERE StateId = " + stateId, "CityName", "CityID");
            return View(model);
        }

        private static List<SelectListItem> PopulateDropDown(string query, string textColumn, string valueColumn)
        {
            List<SelectListItem> items = new List<SelectListItem>();
            string constr = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Connection = con;
                    con.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        while (sdr.Read())
                        {
                            items.Add(new SelectListItem
                            {
                                Text = sdr[textColumn].ToString(),
                                Value = sdr[valueColumn].ToString()
                            });
                        }
                    }
                    con.Close();
                }
            }
            return items;
        }

        [HttpPost]
        public JsonResult AjaxMethod(string type, int value)
        {
            Empdata model = new Empdata();
            switch (type)
            {
                case "CountryId":
                    model.tblState = PopulateDropDown("SELECT StateId, StateName FROM tblState WHERE CountryId = " + value, "StateName", "StateId");
                    break;
                case "StateId":
                    model.tblcity = PopulateDropDown("SELECT Id, Name FROM tblcity WHERE StateId = " + value, "Name", "Id");
                    break;
            }
            return Json(model);
        }   

        public ActionResult EDITEmpData(string Id)
        {
            //DataAccessLayer.DBdata objDB = new DataAccessLayer.DBdata(); //calling class DBdata
            //DataSet ds = objDB.SelectAllEmpbyID(Id);
            //Empdata EM = new Empdata();
            //EM.ID = Convert.ToInt32(ds.Tables[0].Rows[0]["ID"].ToString());
            //EM.Name = ds.Tables[0].Rows[0]["Name"].ToString();
            //EM.Address = ds.Tables[0].Rows[0]["Address"].ToString();            
            //ViewBag.tblcountry = PopulateDropDown("SELECT CountryId, CountryName FROM tblcountry", "CountryName", "CountryId");

            ////EM.tblcountry = PopulateDropDown("SELECT CountryId, CountryName FROM tblcountry", "CountryName", "CountryId");
            ////var selectedItem = EM.tblcountry.Find(p => p.Value == ds.Tables[0].Rows[0]["Country"].ToString());
            ////if (selectedItem != null)
            ////{
            ////    selectedItem.Selected = true;
            ////    ViewBag.Message = selectedItem.Text;
            ////    EM.tblState = PopulateDropDown("SELECT StateId, StateName FROM tblState WHERE CountryId = " + selectedItem.Value , "StateName", "StateId");

            ////    //var selectedstate = EM.tblState.Find(p => p.Value == ds.Tables[0].Rows[0]["State"].ToString());
            ////    //if(selectedstate !=null)
            ////    //{
            ////    //    selectedstate.Selected = true;
            ////    //    ViewBag.state = selectedstate.Text;
            ////    //}
            ////    //ViewBag.Message += "\\nQuantity: " + fruit.Quantity;
            ////}

            //EM.CountryName = ds.Tables[0].Rows[0]["Country"].ToString();
            //EM.StateName = ds.Tables[0].Rows[0]["State"].ToString();
            //EM.CityName = ds.Tables[0].Rows[0]["City"].ToString();         
            //return View(EM);

            DataAccessLayer.DBdata objDB = new DataAccessLayer.DBdata(); //calling class DBdata
            DataSet ds = objDB.SelectAllEmpbyID(Id);
            Empdata EM = new Empdata();
            EM.ID = Convert.ToInt32(ds.Tables[0].Rows[0]["ID"].ToString());
            EM.Name = ds.Tables[0].Rows[0]["Name"].ToString();
            EM.Address = ds.Tables[0].Rows[0]["Address"].ToString();
            ViewBag.tblcountry = PopulateDropDown("SELECT CountryId, CountryName FROM tblcountry", "CountryName", "CountryId");
            EM.tblcountry = PopulateDropDown("SELECT CountryId, CountryName FROM tblcountry", "CountryName", "CountryId");
            var selectedItem = EM.tblcountry.Find(p => p.Text == ds.Tables[0].Rows[0]["Country"].ToString());
            if (selectedItem != null)
            {
                selectedItem.Selected = true;
                // ViewBag.country = selectedItem.Text;
                EM.CountryId = Convert.ToInt32(selectedItem.Value);
                ViewBag.tblState = PopulateDropDown("SELECT StateId, StateName FROM tblState WHERE CountryId = " + selectedItem.Value, "StateName", "StateId");
                EM.tblState = PopulateDropDown("SELECT StateId, StateName FROM tblState WHERE CountryId = " + selectedItem.Value, "StateName", "StateId");
                var selectedstate = EM.tblState.Find(p => p.Text == ds.Tables[0].Rows[0]["State"].ToString());
                if (selectedstate != null)
                {
                    selectedstate.Selected = true;
                    // ViewBag.state = selectedstate.Text;
                    EM.StateId = Convert.ToInt32(selectedstate.Value);
                    ViewBag.tblcity = PopulateDropDown("SELECT Id, Name FROM tblcity WHERE StateId = " + selectedstate.Value, "Name", "Id");
                    EM.tblcity = PopulateDropDown("SELECT Id, Name FROM tblcity WHERE StateId = " + selectedstate.Value, "Name", "Id");
                    var selectedCity = EM.tblcity.Find(p => p.Text == ds.Tables[0].Rows[0]["city"].ToString());
                    if (selectedCity != null)
                    {
                        selectedCity.Selected = true;
                        //ViewBag.City = selectedCity.Text;
                        EM.CityId = Convert.ToInt32(selectedCity.Value);
                    }
                }
            }
            EM.CountryName = ds.Tables[0].Rows[0]["Country"].ToString();
            EM.StateName = ds.Tables[0].Rows[0]["State"].ToString();
            EM.CityName = ds.Tables[0].Rows[0]["City"].ToString();
            return View(EM);
        }

        [HttpPost]
        public ActionResult EDITEmpData(Empdata MD)
        {
            DataAccessLayer.DBdata objDB = new DataAccessLayer.DBdata(); //calling class DBdata
            string result = objDB.UpdateEmpData(MD); // passing Value to DBClass from model
            ViewData["UpdateRecord"] = result; // for dislaying message after saving storing output.
            return RedirectToAction("ShowAllEmpDetails","Emp");
        }

        public ActionResult ShowAllEmpDetails(Empdata MB)
        {
            DataAccessLayer.DBdata objDB = new DataAccessLayer.DBdata(); //calling class DBdata
            MB.StoreAllEmpData = objDB.ShowAllEmpDetails();
            return View(MB);
        }

        public ActionResult DELETEEmpData(string id)
        {
            DataAccessLayer.DBdata objDB = new DataAccessLayer.DBdata(); //calling class DBdata
            DataSet ds = objDB.SelectAllEmpbyID(id);
            Empdata EM = new Empdata();        
            EM.ID = Convert.ToInt32(ds.Tables[0].Rows[0]["ID"].ToString());
            EM.Name = ds.Tables[0].Rows[0]["Name"].ToString();
            EM.Address = ds.Tables[0].Rows[0]["Address"].ToString();

            //////added  byjj
            var selectedItem = EM.tblcountry.Find(p => p.Text == ds.Tables[0].Rows[0]["Country"].ToString());
            if (selectedItem != null)
            {
                selectedItem.Selected = true;
                // ViewBag.country = selectedItem.Text;
                EM.CountryId = Convert.ToInt32(selectedItem.Value);
                ViewBag.tblState = PopulateDropDown("SELECT StateId, StateName FROM tblState WHERE CountryId = " + selectedItem.Value, "StateName", "StateId");
                EM.tblState = PopulateDropDown("SELECT StateId, StateName FROM tblState WHERE CountryId = " + selectedItem.Value, "StateName", "StateId");
                var selectedstate = EM.tblState.Find(p => p.Text == ds.Tables[0].Rows[0]["State"].ToString());
                if (selectedstate != null)
                {
                    selectedstate.Selected = true;
                    // ViewBag.state = selectedstate.Text;
                    EM.StateId = Convert.ToInt32(selectedstate.Value);
                    ViewBag.tblcity = PopulateDropDown("SELECT Id, Name FROM tblcity WHERE StateId = " + selectedstate.Value, "Name", "Id");
                    EM.tblcity = PopulateDropDown("SELECT Id, Name FROM tblcity WHERE StateId = " + selectedstate.Value, "Name", "Id");
                    var selectedCity = EM.tblcity.Find(p => p.Text == ds.Tables[0].Rows[0]["city"].ToString());
                    if (selectedCity != null)
                    {
                        selectedCity.Selected = true;
                        //ViewBag.City = selectedCity.Text;
                        EM.CityId = Convert.ToInt32(selectedCity.Value);
                    }
                }
            }
            EM.CountryName = ds.Tables[0].Rows[0]["Country"].ToString();
            EM.StateName = ds.Tables[0].Rows[0]["State"].ToString();
            EM.CityName = ds.Tables[0].Rows[0]["City"].ToString();
            return View(EM);
            
        }

        [HttpPost]
        public ActionResult DELETEEmpData(Empdata EM)
        {
            DataAccessLayer.DBdata objDB = new DataAccessLayer.DBdata(); //calling class DBdata
            string result = objDB.DELETEEmpData(EM);
            return RedirectToAction("ShowAllEmpDetails", "Emp");
        }

    }
}
