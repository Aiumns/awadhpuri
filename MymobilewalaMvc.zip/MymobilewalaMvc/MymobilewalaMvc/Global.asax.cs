﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace MymobilewalaMvc
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

   public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }

        public static void RegisterRoutes(RouteCollection routes)
        {

            //RouteCollection Mapping By Passing More Than one Route Name 

            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute("ActualBrowse", // Route name
                   "{controller}/{action}/{id}", // URL with parameters
                       new {
                           controller = "User",
                           action = "Login", 
                           id = UrlParameter.Optional });

            //routes.MapRoute("ActualBrowse2", // Route name
            //   "{controller}/{action}/{id}", // URL with parameters
            //       new
            //       {
            //           controller = "Emp",
            //           action = "FillDropDown",
            //           id = UrlParameter.Optional });

            //routes.MapRoute("ActualBrowses3", // Route name
            // "{controller}/{action}/{id}", // URL with parameters
            //     new
            //     {
            //         controller = "Emp",
            //         action = "InsertModelData",
            //         id = UrlParameter.Optional });
         
        }

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RegisterGlobalFilters(GlobalFilters.Filters);
            RegisterRoutes(RouteTable.Routes);
        }
    }
}