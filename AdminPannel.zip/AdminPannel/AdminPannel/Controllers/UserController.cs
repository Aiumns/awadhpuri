﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;
//using System.Web.Mvc;
////using System.Web.WebPages.Html;
//using AdminPannel.Models;
//using System.Configuration;
//using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AdminPannel.Models;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
namespace AdminPannel.Controllers
{
    public class UserController : Controller
    {
        // GET: /User/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Signup() 
        { 
               UserModels model = new UserModels();               
               ViewBag.tblcountry = PopulateDropDown("SELECT CountryId, CountryName FROM tblcountry", "CountryName", "CountryId");
               if (TempData["success"] !=null)  //checking model is valid or not               
                {
                    //ViewData["result3"] = TempData.Peek("result2").ToString();
                    ViewData["insertStatus"] = Convert.ToString(TempData["success"]);                     
                }
                else
                {
                    ViewData["insertStatus"] = null; //TempData.Peek("result2").ToString();
                 }
                //ViewData["result3"] = TempData.Peek("result2").ToString();
                // string data = TempData.Peek("result2").ToString();
                return View(model); 
        }

       public EmptyResult FileUploading(HttpPostedFileBase postedFile)
         {
            if (postedFile != null)
             {
                string path = Server.MapPath("~/Uploads/");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                postedFile.SaveAs(path + Path.GetFileName(postedFile.FileName));
                TempData["fileRoute"] = path + Path.GetFileName(postedFile.FileName);                
             }
             //return RedirectToAction("Signup");  
            return new EmptyResult();
         }

        [HttpPost]
       public ActionResult Signup(UserModels Objuser)
        { 
            if (ModelState.IsValid)  //checking model is valid or not
            {                
                string path = Server.MapPath("~/Uploads/");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                    Objuser.User_pic = "~/Uploads/" + Path.GetFileName(Objuser.User_pic); 
                }
                else if (Directory.Exists(path)) 
                {
                    Objuser.User_pic = "~/Uploads/" + Path.GetFileName(Objuser.User_pic); 
                }              
                // Objuser.User_pic = Convert.ToString(TempData["fileRoute"]); 
                DataAccessLayer.DBdata objDB = new DataAccessLayer.DBdata(); //calling class DBdata
                string result = objDB.UserRegister(Objuser); // passing Value to DBClass from model
                TempData["success"] = result; //"Successfully updated";
                ModelState.Clear(); //clearing model
                return RedirectToAction("Signup");
                //return View();
            }
            else
            {
                ModelState.AddModelError("", "Error in saving data");
                return View();
            }
        }   

        [HttpPost]
        [ActionName("FillDropDown")]
        public ActionResult Signup(int countryId, int stateId, int cityId)
        {
            UserModels model = new UserModels();
            model.tblcountry = PopulateDropDown("SELECT CountryId, CountryName FROM tblcountry", "CountryName", "CountryId");
            model.tblState = PopulateDropDown("SELECT StateId, StateName FROM tblState WHERE CountryId = " + countryId, "StateName", "StateId");
            model.tblcity = PopulateDropDown("SELECT CityId, CityName FROM tblcity WHERE StateId = " + stateId, "CityName", "CityID");
            return View(model);
        }

        private static List<SelectListItem> PopulateDropDown(string query, string textColumn, string valueColumn)
        {
            List<SelectListItem> items = new List<SelectListItem>();
            string constr = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Connection = con;
                    con.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        while (sdr.Read())
                        {
                            items.Add(new SelectListItem
                            {
                                Text = sdr[textColumn].ToString(),
                                Value = sdr[valueColumn].ToString()
                            });
                        }
                    }
                    con.Close();
                }
            }
            return items;
        }


        [HttpPost]
        public JsonResult AjaxMethod(string type, int value)
        {
            UserModels model = new UserModels();
            switch (type)
            {
                case "CountryId":
                    model.tblState = PopulateDropDown("SELECT StateId, StateName FROM tblState WHERE CountryId = " + value, "StateName", "StateId");
                    break;
                case "StateId":
                    model.tblcity = PopulateDropDown("SELECT CityId, CityName FROM tblcity WHERE StateId = " + value, "CityName", "CityId");
                    break;
            }
            return Json(model);
        }          

        public ActionResult SignIn()
        {
            return View();
        }
	}
}