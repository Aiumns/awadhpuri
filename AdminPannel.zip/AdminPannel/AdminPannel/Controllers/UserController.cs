﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AdminPannel.Models;
namespace AdminPannel.Controllers
{
    public class UserController : Controller
    {
        // GET: /User/
        public ActionResult Index()
        {
            return View();
        }
        //[HttpPost]
        public ActionResult Signup(UserModels Objuser)
        {
            if (ModelState.IsValid)  //checking model is valid or not
            {
                DataAccessLayer.DBdata objDB = new DataAccessLayer.DBdata(); //calling class DBdata
                string result = objDB.UserRegister(Objuser); // passing Value to DBClass from model
                ViewData["result"] = result; // for dislaying message after saving storing output.
                ModelState.Clear(); //clearing model
                return View();
            }
            else
            {
                ModelState.AddModelError("", "Error in saving data");
                return View();
            }
        }
        public ActionResult SignIn()
        {
            return View();
        }
	}
}