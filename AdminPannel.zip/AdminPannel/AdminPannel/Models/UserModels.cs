﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace AdminPannel.Models
{
    public class UserModels
    {
        public int User_Id { get; set; }

        [Required(ErrorMessage = "UserName is required.")]
        public string UserName { get; set; }

        //[Required(ErrorMessage = "User Address is required.")]        
        //public string User_Address { get; set; }

        [Required(ErrorMessage = "Email Id is required.")]
        [DataType(DataType.EmailAddress)]        
        public string User_Email { get; set; }

        //[Required(ErrorMessage = "Mobile No is required.")]
        //[StringLength(10, ErrorMessage = "Mobile No Must Be 10th Digit", MinimumLength = 10)]
        //[DataType(DataType.PhoneNumber)]
        [Display(Name = "Mobile No")]
        public string User_MobileNo { get; set; }

        public UserType UserTypes { get; set; }

        public string  TypeOfUsers { get; set; }    

        [Required(ErrorMessage = "Password is required.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Confirmation Password is required.")]
        [Compare("Password", ErrorMessage = "Password and Confirmation Password must match.")]
        public string ConfirmPassword { get; set; }       
    }

    public enum UserType
    {
        Admin,
        Manager,
        Sales
    }
}