﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using mvcdemo.Models;
using System.Web.Security;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
namespace mvcdemo.Controllers
{
    public class LoginController : Controller
    {
        DAL obj = new DAL();

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(HUser  user,string ReturnUrl)
        {
            if (IsValid(user))
            {
                FormsAuthentication.SetAuthCookie(user.UserName, false);
                return Redirect(ReturnUrl);
            }
            else 
            {
                return View(user);  
            }            
        }

        public ActionResult Register()
        {
            GetInitialise_ddl();
            return View();
        }

        //public JsonResult GetState(int Countryid)
        //{            
        //    string Query = "select State_id,State,Country_id from tbl_state where Country_id="+ Countryid +"";
        //    DataTable dt = new DataTable();
        //    dt = obj.ReceiveData(Query);
        //    List<SelectListItem> list = new List<SelectListItem>();
        //    list.Add(new SelectListItem { Text="---Select State---",Value="0" });
        //    foreach (DataRow dr in dt.Rows)
        //    {
        //        list.Add(new SelectListItem { Text = Convert.ToString(dr.ItemArray[0]), Value = Convert.ToString(dr.ItemArray[1]) });
        //    }
        //    return Json(new SelectList(list, "Value", "Text", JsonRequestBehavior.AllowGet));            
        //}

        public JsonResult getstate(int id)
        {
            string Query = "select State_id,State,Country_id from tbl_state where Country_id='" + id + "'";
            DataTable dt = new DataTable();
            dt = obj.ReceiveData(Query);
            List<SelectListItem> list = new List<SelectListItem>();
            //list.Add(new SelectListItem { Text = "--Select Country--", Value = "0" });
            foreach (DataRow row in dt.Rows)
            {
                list.Add(new SelectListItem { Text = Convert.ToString(row.ItemArray[1]), Value = Convert.ToString(row.ItemArray[0]) });
            }
            return Json(new SelectList(list, "Value", "Text", JsonRequestBehavior.AllowGet));
        }

      public JsonResult Getcity(int Id)
        {
            string Query = "select City_id,State_id,City from tbl_city where State_id='" + Id + "'";
            DataTable dt = new DataTable();
            dt = obj.ReceiveData(Query);
            List<SelectListItem> listcity = new List<SelectListItem>();
            foreach (DataRow dr in dt.Rows)
            {
                listcity.Add(new SelectListItem { Text = Convert.ToString(dr.ItemArray[0]), Value = Convert.ToString(dr.ItemArray[2]) });
            }
            return Json(new SelectList(listcity,"Text","Value",JsonRequestBehavior.AllowGet));
        }

       public void GetInitialise_ddl()
        {
            //DAL obj = new DAL();
            string Query = string.Empty;
            DataTable dt;
            Query = "select Country_id,Country_Name from tbl_Country";
            dt = new DataTable();
            dt = obj.ReceiveData(Query);
            List<SelectListItem> countrylist = new List<SelectListItem>();
            countrylist.Add(new SelectListItem { Text = "--Select Country--", Value = "0" });
            foreach (DataRow dr in dt.Rows)
            {
                countrylist.Add(new SelectListItem { Text = Convert.ToString(dr.ItemArray[1]), Value = Convert.ToString(dr.ItemArray[0]) });
            }
            ViewBag.Countrylist = countrylist;
            //Bind State List
            dt = null;
            dt = new DataTable();
            Query = "";
            //Query = "select State_id,State,Country_id from tbl_state";
            //dt = obj.ReceiveData(Query);
            List<SelectListItem> statelist = new List<SelectListItem>();
            statelist.Add(new SelectListItem { Text = "--Select State--", Value = "0" });
            //foreach (DataRow dr in dt.Rows)
            //{
            //    statelist.Add(new SelectListItem { Text = Convert.ToString(dr.ItemArray[1]), Value = Convert.ToString(dr.ItemArray[0]) });
            //}
            ViewBag.Statelist = statelist;
            //Bind City
            dt = null;
            Query = "";
            dt = new DataTable();
            //Query = "select City_id,City,State_id from tbl_city";
            //dt = obj.ReceiveData(Query);
            List<SelectListItem> citylist = new List<SelectListItem>();
            citylist.Add(new SelectListItem { Text = "--Select City--", Value = "0" });
            //foreach (DataRow dr in dt.Rows)
            //{
            //    citylist.Add(new SelectListItem { Text = Convert.ToString(dr.ItemArray[1]), Value = Convert.ToString(dr.ItemArray[0]) });
            //}
            ViewBag.CityList = citylist;
        }
        [HttpPost]
        public ActionResult Register(RUser user)
        {
            string constr = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                string query = @"INSERT INTO [dbo].[RUser]([UserName],[UserProfile],[Address],[ContactNo],[EmailId],[DateOfBirth],[Gender],
                [UserType],[CountryId],[StateId],[CityId],[Pincode],[IsActive]) VALUES(@UserName,@UserProfile,@Address,@ContactNo,@EmailId,
                @DateOfBirth,@Gender,@UserType,@CountryId,@StateId,@CityId,@Pincode,@IsActive)";
                query += "SELECT SCOPE_IDENTITY()";
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Connection = con;
                    con.Open();
                    cmd.Parameters.AddWithValue("@UserName", user.UserName);
                    cmd.Parameters.AddWithValue("@UserProfile", user.UserProfile);
                    cmd.Parameters.AddWithValue("@Address", user.Address);
                    cmd.Parameters.AddWithValue("@ContactNo", user.ContactNo);
                    cmd.Parameters.AddWithValue("@EmailId", user.EmailId);
                    cmd.Parameters.AddWithValue("@DateOfBirth", user.DateOfBirth);
                    cmd.Parameters.AddWithValue("@Gender", user.Gender);
                    cmd.Parameters.AddWithValue("@UserType", user.UserType);
                    cmd.Parameters.AddWithValue("@CountryId", user.CountryId);
                    cmd.Parameters.AddWithValue("@StateId", user.StateId);
                    cmd.Parameters.AddWithValue("@CityId", user.CityId);
                    cmd.Parameters.AddWithValue("@Pincode", user.Pincode);
                    cmd.Parameters.AddWithValue("@IsActive", user.IsActive);                          
                    user.Id = Convert.ToInt32(cmd.ExecuteScalar());
                    con.Close();
                }
            }            
            return View(user);
        }
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return Redirect("/Home/Index");
        }
        private bool IsValid(HUser user)
        {
            return (user.UserName == "test" && user.Password == "123"); 
        }
	}
}