﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace mvcdemo.Models
{
    public class DAL
    {
        DataTable dt;
        SqlDataAdapter da;
        public static SqlConnection connect() 
        { 
            //reading connection string from web.config
            string strcon = ConfigurationManager.ConnectionStrings["mycon"].ConnectionString.ToString();
            //passing the string in sqlconnection
            SqlConnection cnn = new SqlConnection(strcon);
            //Check wheather the connection is close or not if open close it else open it    
            if (cnn.State == ConnectionState.Open)
            {
                cnn.Close();
            }
            else 
            {
                cnn.Open();
            }
            return cnn;
        }
        public DataTable ReceiveData(string query)
        {
            dt = new DataTable();
            da = new SqlDataAdapter(query, DAL.connect());
            da.Fill(dt);
            return dt;
        }
    }
}